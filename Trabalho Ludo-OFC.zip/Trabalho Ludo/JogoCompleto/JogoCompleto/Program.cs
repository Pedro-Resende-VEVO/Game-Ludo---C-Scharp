﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex25
{

    using System;

    public class mapas
    {
        public string[,] mapVisuIni = new string[,]
        { { "#", "#","#","#","#","#","-","-","-","#","#","#","#","#","#" },
        { "#", "z","-","-","z","#","-","#","#","#","y","-","-","y","#" },
        { "#", "-","-","-","-","#","*","#","-","#","-","-","-","-","#" },
        { "#", "-","-","-","-","#","-","#","-","#","-","-","-","-","#" },
        { "#", "z","-","-","z","#","-","#","-","#","y","-","-","y","#" },
        { "#", "#","#","#","#","#","-","#","-","#","#","#","#","#","#" },
        { "-", "#","-","-","-","-","#","#","#","-","-","-","-","-","-" },
        { "-", "#","#","#","#","#","#","#","#","#","#","#","#","#","-" },
        { "-", "-","-","*","-","-","#","#","#","-","*","-","-","#","-" },
        { "#", "#","#","#","#","#","#","#","#","#","#","#","#","#","#" },
        { "#", "x","-","-","x","#","-","#","-","#","w","-","-","w","#" },
        { "#", "-","-","-","-","#","-","#","-","#","-","-","-","-","#" },
        { "#", "-","-","-","-","#","-","#","-","#","-","-","-","-","#" },
        { "#", "x","-","-","x","#","#","#","-","#","w","-","-","w","#" },
        { "#", "#","#","#","#","#","-","-","*","#","#","#","#","#","#" },};

        int[,] mapLog1 = new int[15, 15];
        int[,] mapLog2 = new int[15, 15];

        public int[,] MapJog()
        {
            //subindo inferior
            int cont = 5;
            for (int i = 9; i <= 13; i++)
            {
                mapLog1[i, 6] = cont;
                cont--;
            }
            //esquerda meio
            cont = 10;
            for (int j = 1; j <= 5; j++)
            {
                mapLog1[8, j] = cont;
                cont--;
            }
            //subindo meio
            cont = 13;
            for (int i = 6; i <= 8; i++)
            {
                mapLog1[i, 0] = cont;
                cont--;
            }
            //direita meio
            cont = 14;
            for (int j = 1; j <= 5; j++)
            {
                mapLog1[6, j] = cont;
                cont++;
            }
            cont = 23;
            //subindo superior
            for (int i = 1; i <= 5; i++)
            {
                mapLog1[i, 6] = cont;
                cont--;
            }
            //topo superior
            cont = 24;
            for (int j = 6; j <= 8; j++)
            {
                mapLog1[0, j] = cont;
                cont++;
            }
            //descendo superior
            cont = 27;
            for (int i = 1; i <= 5; i++)
            {
                mapLog1[i, 8] = cont;
                cont++;
            }
            //direita meio
            cont = 32;
            for (int j = 9; j <= 14; j++)
            {
                mapLog1[6, j] = cont;
                cont++;
            }
            //descendo meio
            cont = 37;
            for (int i = 6; i <= 8; i++)
            {
                mapLog1[i, 14] = cont;
                cont++;
            }
            //esquerda meio
            cont = 44;
            for (int j = 9; j <= 14; j++)
            {
                mapLog1[8, j] = cont;
                cont--;
            }
            //descendo inferior
            cont = 45;
            for (int i = 9; i <= 14; i++)
            {
                mapLog1[i, 8] = cont;
                cont++;
            }
            //fundo inferior
            cont = 52;
            for (int j = 6; j <= 8; j++)
            {
                mapLog1[14, j] = cont;
                cont--;
            }
            //subida final jog 1
            cont = 58;
            for (int i = 8; i <= 13; i++)
            {
                mapLog1[i, 7] = cont;
                cont--;
            }
            //ultimo lugar jog 1 == 58

            //subida final jog 2
            cont = 59;
            for (int i = 1; i <= 6; i++)
            {
                mapLog1[i, 7] = cont;
                cont++;
            }
            //ultimo lugar jog 1 == 64


            return mapLog1;
        }

    }
    internal class Program
    {
        int[] PosEstreJog2 = { 17, 24, 34, 48 };
        int[] PosEstreJog1 = { 8, 22, 43, 50 };
        int cont6 = 0;
        int countt = 0;

        /*Funções do Jogador 1*/

        static void regraPossPassP1(int[,] MapaLogJog, int numPeao, string[,] mapVisu, int[] peaoPosPassJog1)
        {
            mapas setMap = new mapas();

            for (int i = 0; i <= 14; i++)
            {
                for (int j = 0; j <= 14; j++)
                {

                    if (peaoPosPassJog1[numPeao] == MapaLogJog[i, j])
                    {
                        if (setMap.mapVisuIni[i, j] == "-")
                        {
                            mapVisu[i, j] = "-";
                        }
                        else if (setMap.mapVisuIni[i, j] == "#")
                        {
                            mapVisu[i, j] = "#";
                        }
                    }
                }
            }
        }

        static void regraDecapituraP1(int[] peaoPosJog1, string[] peaoJog1, int[,] MapaLogJog, int numPeao, int[] peaoPosJog2, string[] peaoJog2, string[,] mapVisu, int[] peaoPosPassJog1)
        {
            mapas setMap = new mapas();
            Program constan = new Program();

            string[] posJog1e2 = new string[4];

            //regra de captura

            for (int i = 0; i <= 3; i++)
            {
                if (peaoPosJog1[numPeao] == peaoPosJog2[i])
                {
                    //regra de safeZone jog2

                    if (peaoPosJog2[i] == constan.PosEstreJog2[0])
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[8, 10] = posJog1e2[i];
                    }
                    else if (peaoPosJog2[i] == constan.PosEstreJog2[1])
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[14, 8] = posJog1e2[i];
                    }
                    else if (peaoPosJog2[i] == constan.PosEstreJog2[2])
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[8, 3] = posJog1e2[i];
                    }
                    else if (peaoPosJog2[i] == constan.PosEstreJog2[3])
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[2, 6] = posJog1e2[i];
                    }
                    else if (peaoPosJog2[i] == 1)
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[13, 6] = posJog1e2[i];
                    }
                    else if (peaoPosJog2[i] == 14)
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[6, 1] = posJog1e2[i];
                    }
                    else if (peaoPosJog2[i] == 27)
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[1, 8] = posJog1e2[i];
                    }
                    else if (peaoPosJog2[i] == 40)
                    {
                        posJog1e2[i] = peaoJog1[numPeao] + "/" + peaoJog2[i];
                        mapVisu[8, 13] = posJog1e2[i];
                    }

                    //retorno ao espaço disponível da fonte

                    for (int j = 0; j <= 3; j++)
                    {
                        if (peaoPosJog2[i] != constan.PosEstreJog2[j])
                        {
                            peaoPosJog2[i] = -1;

                            if (mapVisu[1, 10] == "#")
                            {
                                mapVisu[1, 10] = peaoJog2[i];
                                break;
                            }
                            else if (mapVisu[4, 10] == "#")
                            {
                                mapVisu[4, 10] = peaoJog2[i];
                                break;
                            }
                            else if (mapVisu[4, 13] == "#")
                            {
                                mapVisu[4, 13] = peaoJog2[i];
                                break;
                            }
                            else if (mapVisu[1, 13] == "#")
                            {
                                mapVisu[1, 13] = peaoJog2[i];
                                break;
                            }
                        }
                    }
                    break;
                }
                else
                {
                    constan.countt++;
                }
            }
            if (constan.countt == 4)
            {
                //movimentação pro vazio

                for (int i = 0; i <= 14; i++)
                {
                    for (int j = 0; j <= 14; j++)
                    {
                        if (peaoPosJog1[numPeao] == MapaLogJog[i, j])
                        {
                            mapVisu[i, j] = peaoJog1[numPeao];
                        }
                    }
                }

            }

            regraPossPassP1(MapaLogJog, numPeao, mapVisu, peaoPosPassJog1);

            //Exibição

            Console.Clear();
            Console.WriteLine("---------------------------");
            Console.WriteLine("Mapa atualizado:");
            Console.WriteLine();

            for (int i = 0; i <= 14; i++)
            {
                for (int j = 0; j <= 14; j++)
                {
                    Console.Write(mapVisu[i, j]);
                }
                Console.WriteLine();
            }

            constan.countt = 0;
            Console.ReadKey();
            Console.Clear();
        }

        static void addJogadaP1(int[] peaoPosJog1, string[] peaoJog1, int[,] MapaLogJog, int dadoResult, int[] peaoPosJog2, string[] peaoJog2, string[,] mapVisu)
        {
            mapas setMap = new mapas();
            int[] peaoPosPassJog1 = new int[3];

            Console.WriteLine("(escolha pelo numero escrito a frente do peão disponível)");
            Console.Write("Qual peão deseja mexer?: ");
            int numPeao = int.Parse(Console.ReadLine());

            //movimentação

            if (peaoPosJog1[numPeao] == 0)
            {
                peaoPosJog1[numPeao] = 1;

                if (mapVisu[10, 1] == "x")
                {
                    mapVisu[10, 1] = "#";

                }
                else if (mapVisu[10, 4] == "x")
                {
                    mapVisu[10, 4] = "#";

                }
                else if (mapVisu[13, 1] == "x")
                {
                    mapVisu[13, 1] = "#";

                }
                else if (mapVisu[13, 4] == "x")
                {
                    mapVisu[13, 4] = "#";

                }

            }
            else
            {
                peaoPosPassJog1[numPeao] = peaoPosJog1[numPeao];
                peaoPosJog1[numPeao] = peaoPosJog1[numPeao] + dadoResult;

                //reiniciar posição

                if (peaoPosJog1[numPeao] > 52)
                {
                    for (int i = 6; i >= 1; i--)
                    {
                        if (peaoPosJog1[numPeao] - i == 52)
                        {
                            peaoPosJog1[numPeao] = i;
                        }
                    }
                }

            }

            //regra de captura

            regraDecapituraP1(peaoPosJog1, peaoJog1, MapaLogJog, numPeao, peaoPosJog2, peaoJog2, mapVisu, peaoPosPassJog1);

        }

        static void regraDos6P1(int cont6, int[] peaoPosJog1, string[] peaoJog1, int[,] MapaLogJog, int[] peaoPosJog2, string[] peaoJog2, string[,] mapVisu)
        {
            Program val = new Program();

            if (cont6 == 1)
            {
                Console.WriteLine("Por ter tirado 6, tem direito a mais uma jogada: (vale só até a 2° vez tirando 6)");
                jogadaP1(peaoPosJog1, peaoJog1, MapaLogJog, peaoPosJog2, peaoJog2, mapVisu, cont6);
            }
            if (cont6 == 2)
            {
                Console.WriteLine("Por ter tirado 6, tem direito a mais uma jogada: (vale só até essa vez tirando 6)");
                jogadaP1(peaoPosJog1, peaoJog1, MapaLogJog, peaoPosJog2, peaoJog2, mapVisu, cont6);
            }
            if (cont6 == 3)
            {
                Console.WriteLine("Mesmo tendo tirado 6, acabou suas jogadas (aperte qualquer tecla para continuar)");
                Console.ReadKey();
            }
        }

        static void jogadaP1(int[] peaoPosJog1, string[] peaoJog1, int[,] MapaLogJog, int[] peaoPosJog2, string[] peaoJog2, string[,] mapVisu, int cont6)
        {
            mapas setMap = new mapas();
            Program val = new Program();
            int contDisp = 0, dadoResult;
            string peaoDisp = "";

            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("Aperte qualquer tecla para jogar o dado: ");
            Console.ReadKey();
            Console.WriteLine("----------------------------");
            dadoResult = dados();
            Console.WriteLine("Você tirou o número: " + dadoResult);
            Console.WriteLine("----------------------------");

            //peoes disponiveis e regra do final

            for (int i = 0; i <= 3; i++)
            {
                if (peaoPosJog1[i] > 0)
                {
                    if ((peaoPosJog1[i] + dadoResult) > 57)
                    {
                        Console.WriteLine("O peão " + peaoJog1[i] + " passou o limite de casas e não poderá ser mexido");
                    }
                    else if ((peaoPosJog1[i] + dadoResult) == 57)
                    {
                        Console.WriteLine("O peão " + peaoJog1[i] + " já está no último lugar");
                    }
                    else
                    {
                        peaoDisp += " " + peaoJog1[i];
                        contDisp++;
                    }
                }
            }


            if (dadoResult == 6 && contDisp == 0)
            {
                Console.WriteLine("Você pode apenas escolher uma peça da fonte para mexer e fazer uma nova jogada");
                Console.WriteLine("-----------------------------------------------------------");
                Console.Write("Opções:");
                for (int i = 0; i <= 3; i++)
                {
                    Console.Write(" " + peaoJog1[i]);
                }
                Console.WriteLine();
                addJogadaP1(peaoPosJog1, peaoJog1, MapaLogJog, dadoResult, peaoPosJog2, peaoJog2, mapVisu);
                Console.Clear();
                Console.WriteLine("Nova jogada");
                jogadaP1(peaoPosJog1, peaoJog1, MapaLogJog, peaoPosJog2, peaoJog2, mapVisu, cont6);
            }
            else if (dadoResult == 6 && contDisp > 0)
            {
                cont6++;
                Console.WriteLine("Você pode escolher uma peça da fonte para mexer ou as do tabuleiro");
                Console.Write("Opções:");
                for (int i = 0; i <= 3; i++)
                {
                    Console.Write(" " + peaoJog1[i]);
                }
                Console.WriteLine();
                Console.WriteLine("---------------------------------------------------------------------------------");
                addJogadaP1(peaoPosJog1, peaoJog1, MapaLogJog, dadoResult, peaoPosJog2, peaoJog2, mapVisu);
                regraDos6P1(cont6, peaoPosJog1, peaoJog1, MapaLogJog, peaoPosJog2, peaoJog2, mapVisu);
            }
            else if (dadoResult != 6 && contDisp > 0)
            {
                Console.WriteLine("Você pode mexer a(s) peça(s):" + peaoDisp);
                Console.WriteLine("---------------------------------------------");
                addJogadaP1(peaoPosJog1, peaoJog1, MapaLogJog, dadoResult, peaoPosJog2, peaoJog2, mapVisu);
            }
            else if (dadoResult != 6 && contDisp == 0)
            {
                Console.WriteLine("Não será possível jogar nessa rodada (não tirou 6)");
                Console.WriteLine("------------------------------------------------------");
                Console.ReadKey();
            }
        }

        /*Funções do Jogador 2*/

        static void regraPossPassP2(int[,] MapaLogJog, int numPeao, string[,] mapVisu, int[] peaoPosPassJog2)
        {
            mapas setMap = new mapas();

            for (int i = 0; i <= 14; i++)
            {
                for (int j = 0; j <= 14; j++)
                {

                    if (peaoPosPassJog2[numPeao] == MapaLogJog[i, j])
                    {
                        if (setMap.mapVisuIni[i, j] == "-")
                        {
                            mapVisu[i, j] = "-";
                        }
                        else if (setMap.mapVisuIni[i, j] == "#")
                        {
                            mapVisu[i, j] = "#";
                        }
                    }
                }
            }
        }

        static void regraDecapituraP2(int[] peaoPosJog2, string[] peaoJog2, int[,] MapaLogJog, int numPeao, int[] peaoPosJog1, string[] peaoJog1, string[,] mapVisu, int[] peaoPosPassJog2)
        {
            mapas setMap = new mapas();
            Program constan = new Program();
            string[] posJog1e2 = new string[4];

            //regra de captura

            for (int i = 0; i <= 3; i++)
            {
                if (peaoPosJog2[numPeao] == peaoPosJog1[i])
                {
                    //regra de safeZone jog2

                    if (peaoPosJog1[i] == constan.PosEstreJog2[0])
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[8, 10] = posJog1e2[i];
                    }
                    else if (peaoPosJog1[i] == constan.PosEstreJog2[1])
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[14, 8] = posJog1e2[i];
                    }
                    else if (peaoPosJog1[i] == constan.PosEstreJog2[2])
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[8, 3] = posJog1e2[i];
                    }
                    else if (peaoPosJog1[i] == constan.PosEstreJog2[3])
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[2, 6] = posJog1e2[i];
                    }
                    else if (peaoPosJog1[i] == 1)
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[13, 6] = posJog1e2[i];
                    }
                    else if (peaoPosJog1[i] == 14)
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[6, 1] = posJog1e2[i];
                    }
                    else if (peaoPosJog1[i] == 27)
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[1, 8] = posJog1e2[i];
                    }
                    else if (peaoPosJog1[i] == 40)
                    {
                        posJog1e2[i] = peaoJog2[numPeao] + "/" + peaoJog1[i];
                        mapVisu[8, 13] = posJog1e2[i];
                    }

                    //retorno ao espaço disponível da fonte

                    for (int j = 0; j <= 3; j++)
                    {
                        if (peaoPosJog1[i] != constan.PosEstreJog2[j])
                        {
                            peaoPosJog1[i] = 0;

                            if (mapVisu[10, 1] == "#")
                            {
                                mapVisu[10, 1] = peaoJog1[i];
                                break;
                            }
                            else if (mapVisu[10, 4] == "#")
                            {
                                mapVisu[10, 4] = peaoJog1[i];
                                break;
                            }
                            else if (mapVisu[13, 1] == "#")
                            {
                                mapVisu[13, 1] = peaoJog1[i];
                                break;
                            }
                            else if (mapVisu[13, 4] == "#")
                            {
                                mapVisu[13, 4] = peaoJog1[i];
                                break;
                            }
                        }
                    }
                }
                else
                {
                    constan.countt++;
                }
            }
            if (constan.countt == 4)
            {
                //movimentação pro vazio

                for (int i = 0; i <= 14; i++)
                {
                    for (int j = 0; j <= 14; j++)
                    {
                        if (peaoPosJog2[numPeao] == MapaLogJog[i, j])
                        {
                            mapVisu[i, j] = peaoJog2[numPeao];
                        }
                    }
                }

            }

            regraPossPassP2(MapaLogJog, numPeao, mapVisu, peaoPosPassJog2);

            //Exibição

            Console.Clear();
            Console.WriteLine("---------------------------");
            Console.WriteLine("Mapa atualizado:");
            Console.WriteLine();

            for (int i = 0; i <= 14; i++)
            {
                for (int j = 0; j <= 14; j++)
                {
                    Console.Write(mapVisu[i, j]);
                }
                Console.WriteLine();
            }

            constan.countt = 0;
            Console.ReadKey();
            Console.Clear();
        }

        static void addJogadaP2(int[] peaoPosJog2, string[] peaoJog2, int[,] MapaLogJog, int dadoResult, int[] peaoPosJog1, string[] peaoJog1, string[,] mapVisu)
        {
            mapas setMap = new mapas();
            int[] peaoPosPassJog2 = new int[3];

            Console.WriteLine("(escolha pelo numero escrito a frente do peão disponível)");
            Console.Write("Qual peão deseja mexer?: ");
            int numPeao = int.Parse(Console.ReadLine());

            //movimentação

            if (peaoPosJog2[numPeao] == -1)
            {
                peaoPosJog2[numPeao] = 27;


                if (mapVisu[1, 10] == "y")
                {
                    mapVisu[1, 10] = "#";

                }
                else if (mapVisu[4, 10] == "y")
                {
                    mapVisu[4, 10] = "#";

                }
                else if (mapVisu[1, 13] == "y")
                {
                    mapVisu[1, 13] = "#";

                }
                else if (mapVisu[4, 13] == "y")
                {
                    mapVisu[4, 13] = "#";

                }

            }
            else
            {
                peaoPosPassJog2[numPeao] = peaoPosJog2[numPeao];
                peaoPosJog2[numPeao] = peaoPosJog2[numPeao] + dadoResult;

                //reiniciar posição

                if (peaoPosJog2[numPeao] > 52)
                {
                    for (int i = 6; i >= 1; i--)
                    {
                        if (peaoPosJog2[numPeao] - i == 52)
                        {
                            peaoPosJog2[numPeao] = i;
                        }
                    }
                }

            }

            //regra de captura

            regraDecapituraP2(peaoPosJog2, peaoJog2, MapaLogJog, numPeao, peaoPosJog1, peaoJog1, mapVisu, peaoPosPassJog2);

        }

        static void regraDos6P2(int cont6, int[] peaoPosJog2, string[] peaoJog2, int[,] MapaLogJog, int[] peaoPosJog1, string[] peaoJog1, string[,] mapVisu)
        {
            Program val = new Program();

            if (cont6 == 1)
            {
                Console.WriteLine("Por ter tirado 6, tem direito a mais uma jogada: (vale só até a 2° vez tirando 6)");
                jogadaP2(peaoPosJog2, peaoJog2, MapaLogJog, peaoPosJog1, peaoJog1, mapVisu, cont6);
            }
            if (cont6 == 2)
            {
                Console.WriteLine("Por ter tirado 6, tem direito a mais uma jogada: (vale só até essa vez tirando 6)");
                jogadaP2(peaoPosJog2, peaoJog2, MapaLogJog, peaoPosJog1, peaoJog1, mapVisu, cont6);
            }
            if (cont6 == 3)
            {
                Console.WriteLine("Mesmo tendo tirado 6, acabou suas jogadas (aperte qualquer tecla para continuar)");
                Console.ReadKey();
            }
        }

        static void jogadaP2(int[] peaoPosJog2, string[] peaoJog2, int[,] MapaLogJog, int[] peaoPosJog1, string[] peaoJog1, string[,] mapVisu, int cont6)
        {
            mapas setMap = new mapas();
            Program val = new Program();

            int contDisp = 0, dadoResult;
            string peaoDisp = "";

            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("Aperte qualquer tecla para jogar o dado: ");
            Console.ReadKey();
            Console.WriteLine("----------------------------");
            dadoResult = dados();
            Console.WriteLine("Você tirou o número: " + dadoResult);
            Console.WriteLine("----------------------------");

            //peoes disponiveis e regra do final

            for (int i = 0; i <= 3; i++)
            {
                if (peaoPosJog2[i] > 0)
                {
                    if ((peaoPosJog2[i] + dadoResult) > 64)
                    {
                        Console.WriteLine("O peão " + peaoJog2[i] + " passou o limite de casas e não poderá ser mexido");
                    }
                    else if ((peaoPosJog2[i] + dadoResult) == 64)
                    {
                        Console.WriteLine("O peão " + peaoJog2[i] + " já está no último lugar");
                    }
                    else
                    {
                        peaoDisp += " " + peaoJog2[i];
                        contDisp++;
                    }
                }
            }


            if (dadoResult == 6 && contDisp == 0)
            {
                Console.WriteLine("Você pode apenas escolher uma peça da fonte para mexer e fazer uma nova jogada");
                Console.WriteLine("-----------------------------------------------------------");
                Console.Write("Opções:");
                for (int i = 0; i <= 3; i++)
                {
                    Console.Write(" " + peaoJog2[i]);
                }
                Console.WriteLine();
                addJogadaP2(peaoPosJog2, peaoJog2, MapaLogJog, dadoResult, peaoPosJog1, peaoJog1, mapVisu);
                Console.Clear();
                Console.WriteLine("Nova jogada");
                jogadaP2(peaoPosJog2, peaoJog2, MapaLogJog, peaoPosJog1, peaoJog1, mapVisu, cont6);
            }
            else if (dadoResult == 6 && contDisp > 0)
            {
                cont6++;
                Console.WriteLine("Você pode escolher uma peça da fonte para mexer ou as do tabuleiro");
                Console.Write("Opções:");
                for (int i = 0; i <= 3; i++)
                {
                    Console.Write(" " + peaoJog2[i]);
                }
                Console.WriteLine();
                Console.WriteLine("---------------------------------------------------------------------------------");
                addJogadaP2(peaoPosJog2, peaoJog2, MapaLogJog, dadoResult, peaoPosJog1, peaoJog1, mapVisu);
                regraDos6P2(cont6, peaoPosJog2, peaoJog2, MapaLogJog, peaoPosJog1, peaoJog1, mapVisu);
            }
            else if (dadoResult != 6 && contDisp > 0)
            {
                Console.WriteLine("Você pode mexer a(s) peça(s):" + peaoDisp);
                Console.WriteLine("---------------------------------------------");
                addJogadaP2(peaoPosJog2, peaoJog2, MapaLogJog, dadoResult, peaoPosJog1, peaoJog1, mapVisu);
            }
            else if (dadoResult != 6 && contDisp == 0)
            {
                Console.WriteLine("Não será possível jogar nessa rodada (não tirou 6)");
                Console.WriteLine("------------------------------------------------------");
                Console.ReadKey();
            }
        }

        static int dados()
        {
            Random numRand = new Random();
            int numDado = numRand.Next(1, 7);
            return numDado;
        }

        static void Main(string[] args)
        {
            string[,] mapVisu = new string[,]
        { { "#", "#","#","#","#","#","-","-","-","#","#","#","#","#","#" },
        { "#", "z","-","-","z","#","-","#","#","#","y","-","-","y","#" },
        { "#", "-","-","-","-","#","*","#","-","#","-","-","-","-","#" },
        { "#", "-","-","-","-","#","-","#","-","#","-","-","-","-","#" },
        { "#", "z","-","-","z","#","-","#","-","#","y","-","-","y","#" },
        { "#", "#","#","#","#","#","-","#","-","#","#","#","#","#","#" },
        { "-", "#","-","-","-","-","#","#","#","-","-","-","-","-","-" },
        { "-", "#","#","#","#","#","#","#","#","#","#","#","#","#","-" },
        { "-", "-","-","*","-","-","#","#","#","-","*","-","-","#","-" },
        { "#", "#","#","#","#","#","#","#","#","#","#","#","#","#","#" },
        { "#", "x","-","-","x","#","-","#","-","#","w","-","-","w","#" },
        { "#", "-","-","-","-","#","-","#","-","#","-","-","-","-","#" },
        { "#", "-","-","-","-","#","-","#","-","#","-","-","-","-","#" },
        { "#", "x","-","-","x","#","#","#","-","#","w","-","-","w","#" },
        { "#", "#","#","#","#","#","-","-","*","#","#","#","#","#","#" },};

            //variáveis
            mapas setMap = new mapas();
            Program val = new Program();
            int vez = 1, resp = 0;
            bool fim = false;
            string[] peaoJog1 = { "x0", "x1", "x2", "x3" };
            int[] peaoPosJog1 = { 0, 0, 0, 0 };
            string[] peaoJog2 = { "y0", "y1", "y2", "y3" };
            int[] peaoPosJog2 = { -1, -1, -1, -1 };
            int[,] MapaLogJog = setMap.MapJog();
            int cont6 = 0;

            //inicializando mapa
            //setMap.Map(0, 0, "#", peaoJog1[1],2);

            //início
            while (fim == false)
            {
                if (vez == 1)
                {
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("---------Vez do jogador 1---------");
                    Console.WriteLine("----------------------------------");
                    resp = 1;
                }
                else if (vez == 2)
                {
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("---------Vez do jogador 2---------");
                    Console.WriteLine("----------------------------------");
                    resp = 2;
                }

                //exibir tabuleiro

                for (int i = 0; i <= 14; i++)
                {
                    for (int j = 0; j <= 14; j++)
                    {
                        Console.Write(mapVisu[i, j]);
                    }
                    Console.WriteLine();
                }

                // add jogada

                if (vez == 1)
                {

                    jogadaP1(peaoPosJog1, peaoJog1, MapaLogJog, peaoPosJog2, peaoJog2, mapVisu, cont6);
                    cont6 = 0;
                }
                else if (vez == 2)
                {
                    jogadaP2(peaoPosJog2, peaoJog2, MapaLogJog, peaoPosJog1, peaoJog1, mapVisu, cont6);
                    cont6 = 0;
                }

                // condições de vitória

                for (int i = 0; i <= 3; i++)
                {
                    if (peaoPosJog1[1] == 58 && peaoPosJog1[2] == 58 && peaoPosJog1[3] == 58 && peaoPosJog1[4] == 58)
                    {
                        fim = true;
                    }
                    else if (peaoPosJog2[1] == 64 && peaoPosJog2[2] == 64 && peaoPosJog2[3] == 64 && peaoPosJog2[4] == 64)
                    {
                        fim = true;
                    }
                }


                vez++;
                if (vez == 3)
                {
                    vez = 1;
                }
                Console.Clear();
            }

            //exibir resultado

            if (resp == 1)
            {
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("---------Vitória do jogador 1---------");
                Console.WriteLine("----------------------------------");
            }
            else if (resp == 2)
            {
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("---------Vitória do jogador 2---------");
                Console.WriteLine("----------------------------------");
            }

            Console.ReadKey();
        }
    }
}
